<?
require "../configs/config.php";
header("Location: $URL/index.php?action=body");
?>
