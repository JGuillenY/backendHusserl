<?PHP
				
#Archivo Generado Automáticamente por SecureNet PERL SCRIPTING FRAMEWORK
				

class header extends helperController{
					
	function index(){
	}
				
}
?>
