<iframe  src=<?echo URL."public/bienvenido.html";?> width="100%" height="600" 
marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0"  scrolling="no"></iframe>
