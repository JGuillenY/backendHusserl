<?
/**
 * In this file, you can set up 'the main config' for the whole framework
 * generator.
 * @package snfm
 * @subpackage snfm.config
 * @Author Cake development Team
 */

$SCRIPTS[]="";

?>
