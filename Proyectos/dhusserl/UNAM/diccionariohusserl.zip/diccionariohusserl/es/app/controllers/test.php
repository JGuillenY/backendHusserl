<?echo md5("test123")."\n";
